function show() {
    var video = document.getElementById("video");
    var audio = document.getElementById("audio");
    video.style.display = "block";
    audio.style.display = "block";
}


function hide() {
    var video = document.getElementById("video");
    var audio = document.getElementById("audio");
    video.style.display = "none";
    audio.style.display = "none";
}