const projects = [
    {
        title:'My Project 1',
        desc:'My personal project using Vanilla JS',
        url:'http://www.myproject1.com',
        profile:'image/icon1.png'         
    },

     {
        title:'My Project 2',
        desc:'My personal project using React',
        url:'http://www.myproject2.com',
        profile:'image/icon2.png' 
    },

     {
        title:'My Project 3',
        desc:'My personal project using Express JS & Handlebars',
        url:'http://www.myproject3.com',
        profile:'image/icon3.png' 
    }
]

exports.projects = projects;