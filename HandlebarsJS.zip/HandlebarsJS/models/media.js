
const video = {
    id:'video',
    src:'image/nyc480.mov'
}

const audio = {
    id:'audio',
    src:'https://youtu.be/l210g5PbV9c'
}

module.exports = {video,audio};